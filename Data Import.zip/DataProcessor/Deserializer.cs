﻿namespace Trucks.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using Trucks.Data.Models;
    using Trucks.Data.Models.Enums;
    using Trucks.DataProcessor.ImportDto;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedDespatcher
            = "Successfully imported despatcher - {0} with {1} trucks.";

        private const string SuccessfullyImportedClient
            = "Successfully imported client - {0} with {1} trucks.";

        public static string ImportDespatcher(TrucksContext context, string xmlString)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ImportDespatchersDto[]), new XmlRootAttribute("Despatchers"));
            using StringReader reader = new StringReader(xmlString);
            StringBuilder sb = new StringBuilder();

            ImportDespatchersDto[] importDespatchers = (ImportDespatchersDto[])serializer.Deserialize(reader);
            List<Despatcher> despatchers = new List<Despatcher>();

            foreach (var dto in importDespatchers)
            {
                if (!IsValid(dto) || string.IsNullOrEmpty(dto.Position))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                Despatcher despatcher = new Despatcher()
                {
                    Name = dto.Name,
                    Position = dto.Position,
                };

                foreach (var tr in dto.Trucks)
                {
                    if (!IsValid(tr))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (string.IsNullOrEmpty(tr.RegistrationNumber))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    Truck truck = new Truck()
                    {
                        RegistrationNumber = tr.RegistrationNumber,
                        VinNumber = tr.VinNumber,
                        TankCapacity = tr.TankCapacity,
                        CargoCapacity = tr.CargoCapacity,
                        CategoryType = (CategoryType)tr.CategoryType,
                        MakeType = (MakeType)tr.MakeType
                    };

                    despatcher.Trucks.Add(truck);
                }
              
                sb.AppendLine(string.Format(SuccessfullyImportedDespatcher, despatcher.Name, despatcher.Trucks.Count));
                despatchers.Add(despatcher);
            }

            context.Despatchers.AddRange(despatchers);
            context.SaveChanges();
            return sb.ToString().TrimEnd();
        }

        public static string ImportClient(TrucksContext context, string jsonString)
        {
            ImportClientsDto[] clientsDto = JsonConvert.DeserializeObject<ImportClientsDto[]>(jsonString);
            var sb = new StringBuilder();
            List<Client> clients = new List<Client>();

            foreach (var dto in clientsDto)
            {
                if (!IsValid(dto) || dto.Type == "usual")
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                Client client = new Client()
                {
                    Name = dto.Name,
                    Nationality = dto.Nationality,
                    Type = dto.Type
                };

                foreach (var tr in dto.Trucks.Distinct())
                {
                    var id = context.Trucks.Where(x => x.Id == tr).FirstOrDefault();

                    if (id == null)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    client.ClientsTrucks.Add(new ClientTruck() { TruckId = tr });
                }

                clients.Add(client);
                sb.AppendLine(string.Format(SuccessfullyImportedClient, client.Name, client.ClientsTrucks.Count));
            }

            context.Clients.AddRange(clients);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}
