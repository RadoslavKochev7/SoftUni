﻿namespace Trucks.DataProcessor
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using Trucks.DataProcessor.ExportDto;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportClientsWithMostTrucks(TrucksContext context, int capacity)
        {
            var exportClients = context.Clients
                .Where(x => x.ClientsTrucks.Any(ct => ct.Truck.TankCapacity >= capacity))
                .ToArray()
                .OrderByDescending(x => x.ClientsTrucks.Where(ct => ct.Truck.TankCapacity >= capacity).Count())
                .ThenBy(t => t.Name)
                .Take(10)
                .Select(c => new
                {
                    Name = c.Name,
                    Trucks = c.ClientsTrucks
                      .Where(x => x.Truck.TankCapacity >= capacity)
                      .Select(ct => new
                      {
                        TruckRegistrationNumber = ct.Truck.RegistrationNumber,
                        VinNumber = ct.Truck.VinNumber,
                        TankCapacity = ct.Truck.TankCapacity,
                        CargoCapacity = ct.Truck.CargoCapacity,
                        CategoryType = ct.Truck.CategoryType.ToString(),
                        MakeType = ct.Truck.MakeType.ToString()
                      })
                      .OrderBy(t => t.MakeType)
                      .ThenByDescending(t => t.CargoCapacity)
                      .ToArray()
                })
                
                .ToArray();

            string result = JsonConvert.SerializeObject(exportClients, Formatting.Indented);
            return result;
        }

        public static string ExportDespatchersWithTheirTrucks(TrucksContext context)
        {
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);
            var sb = new StringBuilder();
            using StringWriter writer = new StringWriter(sb);
            XmlSerializer serializer = new XmlSerializer(typeof(ExportDespatchers[]), new XmlRootAttribute("Despatchers"));

            var export = context.Despatchers
                .Where(d => d.Trucks.Any())
                .ToArray()
                .Select(d => new ExportDespatchers()
                {
                    TrucksCount = d.Trucks.Count,
                    DespatcherName = d.Name,
                    Trucks = d.Trucks.Select(dt => new TrucksExportDto()
                    {
                        RegistrationNumber = dt.RegistrationNumber,
                        Make = dt.MakeType.ToString()
                    })
                    .OrderBy(d => d.RegistrationNumber)
                    .ToArray()
                })
                .OrderByDescending(t => t.TrucksCount)
                .ThenBy(d => d.DespatcherName)
                .ToArray();

            serializer.Serialize(writer, export, namespaces);
            return sb.ToString().TrimEnd();
        }
    }
}
