﻿using Microsoft.Extensions.Configuration;
using MVCTestProject.Core.Contracts;
using MVCTestProject.Core.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCTestProject.Core.Services
{
    /// <summary>
    /// Manipulates product data
    /// </summary>
    public class ProductService : IProductService
    {
        private readonly IConfiguration config;

        /// <summary>
        /// IoC
        /// </summary>
        /// <param name="_config">App configuration</param>
        public ProductService(IConfiguration _config)
        {
            config = _config;
        }
        /// <summary>
        /// Gets all products
        /// </summary>
        /// <returns>List<Products></Products></returns>
        public async Task<IEnumerable<ProductDto>> GetAll()
        {
            string dataPath = config.GetSection("DataFiles:Products").Value;
            string data = await File.ReadAllTextAsync(dataPath);

            return JsonConvert.DeserializeObject<IEnumerable<ProductDto>>(data)!;
        }
    }
}
